import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

# Carico il dataset
data = pd.read_csv("./insurance.csv")

# Raccolgo le informazioni relative al dataset
data.info()

# Controllo valori NaN
null_value = data.isna().sum()
print(null_value)

# Rimuovo le righe con valori mancanti
data = data.dropna()

# Sostituisco i valori mancanti con un valore specifico
data = data.fillna(0)

# Rimuovo duplicati
data = data.drop_duplicates()

# Inizio a fare un'analisi esplorativa con la funzione describe
describe_df = data.describe()

# Imposto uno stile del dataframe per una migliore visualizzazione

sns.set(style="whitegrid")
plt.figure(figsize=(12, 6))


# Creo una heatmap con il risultato di describe
sns.heatmap(describe_df, annot=True, fmt=".2f", cmap='coolwarm', linewidths=.5, cbar=False)

plt.title('Descrizione del Dataset')
plt.savefig("Descrizione_dataset.png")
plt.show()
