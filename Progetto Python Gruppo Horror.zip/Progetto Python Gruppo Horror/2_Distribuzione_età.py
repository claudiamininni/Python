import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

data = pd.read_csv("./analisi_pulite.csv")

# Calcola la percentuale di maschi e femmine
percentuale_sesso = (data['sex'].value_counts() / len(data)) * 100

print(f"Percentuale di maschi: {percentuale_sesso['male']:.1f}%")
print(f"Percentuale di femmine: {percentuale_sesso['female']:.1f}%")


# Calcola la percentuale di fumatori e non fumatori
percentuale_fumatori = (data['smoker'].value_counts() / len(data)) * 100


print(f"Percentuale di fumatori: {percentuale_fumatori['yes']:.1f}%")
print(f"Percentuale di non fumatori: {percentuale_fumatori['no']:.1f}%")


# Distribuzione dell'età
conteggio_per_eta = data['age'].value_counts().sort_index()


plt.figure(figsize=(12, 6))
sns.barplot(x=conteggio_per_eta.index, y=conteggio_per_eta.values,color='blue')
plt.title('Distribuzione delle età)')
plt.xlabel('Età')
plt.ylabel('Conteggio')
plt.savefig("Distribuzione_età.png")
plt.show()


