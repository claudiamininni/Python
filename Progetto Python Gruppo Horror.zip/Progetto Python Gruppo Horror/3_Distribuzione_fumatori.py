import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

data = pd.read_csv("./analisi_pulite.csv")


# Differenze di costo tra fumatori e non fumatori
print("\nAnalisi delle differenze di costo tra fumatori e non fumatori:")
spese_per_fumatori = data[data['smoker'] == 'yes']['charges']
spese_per_non_fumatori = data[data['smoker'] == 'no']['charges']
print("Media spese per fumatori:", spese_per_fumatori.mean())
print("Media spese per non fumatori:", spese_per_non_fumatori.mean())
plt.figure(figsize=(10, 6))
sns.boxplot(x='smoker', y='charges', data=data)
plt.title('Spesa sanitaria tra fumatori e non fumatori')
plt.xlabel('Fumatore')
plt.ylabel('Spese mediche')
plt.savefig("Distribuzione_fumatori.png")
plt.show()