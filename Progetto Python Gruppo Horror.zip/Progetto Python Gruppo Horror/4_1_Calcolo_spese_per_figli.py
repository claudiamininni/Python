import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

data = pd.read_csv("./analisi_pulite.csv")

# Calcolo spese medie per ciascun numero di figli
spese_medie_per_numero_figli = data.groupby('children')['charges'].mean()
plt.bar(spese_medie_per_numero_figli.index, spese_medie_per_numero_figli.values)
plt.xlabel('Numero di figli')
plt.ylabel('Spese medie')
plt.title('Distribuzione delle spese mediche per numero di figli')
plt.savefig("Calcolo_spese_per_figli.png")
plt.show()